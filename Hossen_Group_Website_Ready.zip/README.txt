HOSSEN GROUP OF COMPANY — WEBSITE

Files:
- index.html
- style.css
- script.js
- assets/hossen-logo.png
- assets/home-banner.png

How to run:
1. Keep the folder structure unchanged.
2. Open index.html in a browser.
3. For a real website, upload the whole folder to your hosting/public_html.

Important:
- The contact form is frontend-only in this version.
- Replace the demo email/phone/location with the real company details.
- To receive messages, connect the form to PHP, Formspree, a server API, or your hosting email service.
